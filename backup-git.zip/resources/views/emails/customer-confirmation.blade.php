<h1>Order Confirmation</h1>

<p>Hi {{ $charge->source->name }}, your X Cloud Vision is on the way!</p>

<p>Your order number is {{ $charge->id }}</p></p>

<p>Internxt Inc.</p>
