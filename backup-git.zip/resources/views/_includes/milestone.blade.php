<div class="subsection subsection--milestone" data-key="{{ str_slug($date) }}">
	<p class="subsection__label">{{ $date }}</p>
	<p class="subsection__heading">{{ $title }}</p>
	<p class="subsection__content subsection__content--active">{{ $content }}</p>
</div>{{-- /.subsection --}}
