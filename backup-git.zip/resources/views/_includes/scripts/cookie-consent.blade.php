<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.1.0/cookieconsent.min.css" />
<link rel="stylesheet" type="text/css" href="/css/cookie-consent.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.1.0/cookieconsent.min.js"></script>
<script>
    window.addEventListener("load", function(){
    window.cookieconsent.initialise({
      "palette": {
        "popup": {
          "background": "#ffffff",
          "text": "#000000"
        },
        "button": {
          "background": "#000000",
          "text": "#ffffff"
        }
      },
      "theme": "edgeless",
      "content": {
        "message": "We use cookies to ensure you get the best experience on our website.",
        "dismiss": "",
        "link": ""
      }
    })});
</script>
