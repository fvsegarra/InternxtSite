{{-- Global site tag (gtag.js) - AdWords: 926597150 --}}
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-926597150"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'AW-926597150');
</script>
<script>
    gtag('event', 'page_view', {
    'send_to': 'AW-926597150',
    'user_id': 'replace with value'
    });
</script>
