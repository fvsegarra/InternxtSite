<li class="nav-item nav-item--social">
    <a class="nav-link" rel="nofollow" target="_blank" href="https://twitter.com/Internxt"><img src="/img/logos/twitter.png" height="22"></a>
</li>
<li class="nav-item nav-item--social">
    <a class="nav-link" rel="nofollow" target="_blank" href="https://medium.com/internxt"><img src="/img/logos/medium.png" height="22"></a>
</li>
<li class="nav-item nav-item--social">
    <a class="nav-link" rel="nofollow" target="_blank" href="https://github.com/Internxt/"><img src="/img/logos/github.png" height="22"></a>
</li>
<li class="nav-item nav-item--social">
    <a class="nav-link" rel="nofollow" target="_blank" href="mailto:hello@internxt.com"><img src="/img/logos/mail.png" height="21"></a>
</li>
<li class="nav-item nav-item--social">
    <a class="nav-link" rel="nofollow" target="_blank" href="tg://resolve?domain=InternxtHQ"><img src="/img/logos/telegram.png" height="21"></a>
</li>
<li class="nav-item nav-item--social">
    <a class="nav-link" rel="nofollow" target="_blank" href="https://www.instagram.com/InternxtHQ/"><img src="/img/logos/instagram.png" height="22"></a>
</li>
