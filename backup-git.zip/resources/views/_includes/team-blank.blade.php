<div class="teamMember teamMember--blank">
    <div class="teamMember__text">
        <h3 class="teamMember__heading">{{ $name }}</h3>
        <p class="teamMember__subheading">{{ $position }}</p>
        <a href="{{ $btnLink }}" class="btn teamMember__btn">{{ $btnText }}</a>
    </div>
</div>
